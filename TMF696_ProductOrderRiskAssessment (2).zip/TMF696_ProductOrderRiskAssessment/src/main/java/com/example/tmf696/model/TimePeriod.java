package com.example.tmf696.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.time.OffsetDateTime;

@ApiModel(description = "A period of time with start and end date-time")
public class TimePeriod {
    @ApiModelProperty(value = "Start date and time of the period")
    @JsonProperty("startDateTime")
    private OffsetDateTime startDateTime;

    @ApiModelProperty(value = "End date and time of the period")
    @JsonProperty("endDateTime")
    private OffsetDateTime endDateTime;

    // Getters and Setters
    public OffsetDateTime getStartDateTime() { return startDateTime; }
    public void setStartDateTime(OffsetDateTime startDateTime) { this.startDateTime = startDateTime; }
    public OffsetDateTime getEndDateTime() { return endDateTime; }
    public void setEndDateTime(OffsetDateTime endDateTime) { this.endDateTime = endDateTime; }
}