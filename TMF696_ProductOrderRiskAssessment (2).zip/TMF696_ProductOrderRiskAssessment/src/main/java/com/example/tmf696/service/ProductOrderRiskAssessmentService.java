package com.example.tmf696.service;


import com.example.tmf696.model.Characteristic;
import com.example.tmf696.model.ProductOrderRef;
import com.example.tmf696.model.ProductOrderRiskAssessment;
import com.example.tmf696.model.RelatedPlace;
import com.example.tmf696.model.RiskAssessmentResult;
import com.example.tmf696.model.RiskScore;
import com.example.tmf696.model.RiskType;
import com.example.tmf696.model.TimePeriod;

import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.*;

@Service
public class ProductOrderRiskAssessmentService {

    // In-memory storage for mocked data
    private final Map<String, ProductOrderRiskAssessment> assessments = new HashMap<>();

    public ProductOrderRiskAssessmentService() {
        initializeMockData();
    }

    private void initializeMockData() {
        // Create initial mock assessments
        createMockAssessment("1", "InProgress");
        createMockAssessment("2", "Completed");
        createMockAssessment("3", "Failed");
    }

    private void createMockAssessment(String id, String status) {
        ProductOrderRiskAssessment assessment = new ProductOrderRiskAssessment();
        assessment.setId(id);
        assessment.setHref("/tmf-api/riskManagement/v4/productOrderRiskAssessment/" + id);
        assessment.setStatus(status);

        // Set product order reference
        ProductOrderRef productOrderRef = new ProductOrderRef();
        productOrderRef.setId("PO-" + id);
        productOrderRef.setHref("/tmf-api/productOrder/v4/productOrder/PO-" + id);
        productOrderRef.setName("Product Order " + id);
        productOrderRef.setReferredType("ProductOrder");
        assessment.setProductOrder(productOrderRef);

        // Set characteristics
        Characteristic characteristic = new Characteristic();
        characteristic.setName("OrderPriority");
        characteristic.setValueType("string");
        characteristic.setValue("High");
        assessment.setCharacteristic(Collections.singletonList(characteristic));

        // Set place
        RelatedPlace place = new RelatedPlace();
        place.setId("LOC-" + id);
        place.setHref("/tmf-api/geographicAddress/v4/geographicAddress/LOC-" + id);
        place.setName("Location " + id);
        place.setRole("DeliveryAddress");
        place.setReferredType("GeographicAddress");
        assessment.setPlace(place);

        // Set risk assessment result if completed
        if ("Completed".equals(status)) {
            assessment.setRiskAssessmentResult(createMockRiskResult());
        }

        assessments.put(id, assessment);
    }

    private RiskAssessmentResult createMockRiskResult() {
        RiskAssessmentResult result = new RiskAssessmentResult();
        result.setOverallScore(calculateOverallScore());
        
        TimePeriod validFor = new TimePeriod();
        validFor.setStartDateTime(OffsetDateTime.now(ZoneOffset.UTC));
        validFor.setEndDateTime(OffsetDateTime.now(ZoneOffset.UTC).plusDays(30));
        result.setValidFor(validFor);
        
        result.setScore(Arrays.asList(
            createRiskScore(RiskType.FraudRisk, 25.5f),
            createRiskScore(RiskType.BadPaymentRisk, 15.2f),
            createRiskScore(RiskType.CreditGamingRisk, 8.7f),
            createRiskScore(RiskType.IDConfidenceRisk, 5.0f),
            createRiskScore(RiskType.PaymentMethodRisk, 12.3f)
        ));
        
        return result;
    }

    private RiskScore createRiskScore(RiskType riskType, float score) {
        RiskScore riskScore = new RiskScore();
        riskScore.setRiskName(riskType);
        riskScore.setScore(score);
        riskScore.setBaseType("RiskScore");
        riskScore.setType("RiskScore");
        return riskScore;
    }

    private float calculateOverallScore() {
        // Simple mock calculation - in real implementation would use proper algorithm
        return new Random().nextFloat() * 100;
    }

    public List<ProductOrderRiskAssessment> findAll(String status, Integer limit, Integer offset) {
        List<ProductOrderRiskAssessment> result = new ArrayList<>(assessments.values());
        
        // Apply status filter if provided
        if (status != null && !status.isEmpty()) {
            result.removeIf(assessment -> !status.equalsIgnoreCase(assessment.getStatus()));
        }
        
        // Apply pagination
        if (offset != null && offset > 0) {
            result = result.subList(Math.min(offset, result.size()), result.size());
        }
        
        if (limit != null && limit > 0) {
            result = result.subList(0, Math.min(limit, result.size()));
        }
        
        return result;
    }

    public ProductOrderRiskAssessment findById(String id) {
        return assessments.get(id);
    }

    public ProductOrderRiskAssessment create(ProductOrderRiskAssessment assessment) {
        // Generate new ID
        String newId = UUID.randomUUID().toString();
        assessment.setId(newId);
        assessment.setHref("/tmf-api/riskManagement/v4/productOrderRiskAssessment/" + newId);
        
        // Set default status if not provided
        if (assessment.getStatus() == null) {
            assessment.setStatus("InProgress");
        }
        
        // Simulate async processing for InProgress status
        if ("InProgress".equals(assessment.getStatus())) {
            new Thread(() -> {
                try {
                    Thread.sleep(2000); // Simulate processing delay
                    assessment.setStatus("Completed");
                    assessment.setRiskAssessmentResult(createMockRiskResult());
                } catch (InterruptedException e) {
                    assessment.setStatus("Failed");
                }
            }).start();
        } else if ("Completed".equals(assessment.getStatus())) {
            assessment.setRiskAssessmentResult(createMockRiskResult());
        }
        
        assessments.put(newId, assessment);
        return assessment;
    }

    public void delete(String id) {
        assessments.remove(id);
    }

    // Additional helper method for testing
    public void clearAll() {
        assessments.clear();
        initializeMockData();
    }
}
