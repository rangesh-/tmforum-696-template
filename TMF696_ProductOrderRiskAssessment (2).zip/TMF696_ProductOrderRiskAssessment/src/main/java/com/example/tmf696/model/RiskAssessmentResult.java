package com.example.tmf696.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(description = "The result of the risk assessment")
public class RiskAssessmentResult {
    @ApiModelProperty(value = "Overall assessment score")
    private Float overallScore;

    @ApiModelProperty(value = "Period for which this result is valid")
    private TimePeriod validFor;

    @ApiModelProperty(value = "List of individual risk scores")
    private List<RiskScore> score;

    @JsonProperty("@baseType")
    private String baseType;

    @JsonProperty("@schemaLocation")
    private String schemaLocation;

    @JsonProperty("@type")
    private String type;

    // Getters and Setters
    public Float getOverallScore() { return overallScore; }
    public void setOverallScore(Float overallScore) { this.overallScore = overallScore; }
    public TimePeriod getValidFor() { return validFor; }
    public void setValidFor(TimePeriod validFor) { this.validFor = validFor; }
    public List<RiskScore> getScore() { return score; }
    public void setScore(List<RiskScore> score) { this.score = score; }
    public String getBaseType() { return baseType; }
    public void setBaseType(String baseType) { this.baseType = baseType; }
    public String getSchemaLocation() { return schemaLocation; }
    public void setSchemaLocation(String schemaLocation) { this.schemaLocation = schemaLocation; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
