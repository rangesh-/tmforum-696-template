package com.example.tmf696.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(description = "Task resource allowing assessment of risks associated with a product order")
public class ProductOrderRiskAssessment {
    @ApiModelProperty(value = "Unique identifier of the risk assessment")
    private String id;

    @ApiModelProperty(value = "Reference URL of the risk assessment")
    private String href;

    @ApiModelProperty(value = "Status of the risk assessment (InProgress, Completed, Failed)")
    private String status;

    @ApiModelProperty(value = "The product order being assessed", required = true)
    private ProductOrderRef productOrder;

    @ApiModelProperty(value = "List of characteristics for assessment")
    private List<Characteristic> characteristic;

    @ApiModelProperty(value = "Place related to the assessment")
    private RelatedPlace place;

    @ApiModelProperty(value = "Results of the risk assessment")
    private RiskAssessmentResult riskAssessmentResult;

    @JsonProperty("@baseType")
    private String baseType;

    @JsonProperty("@schemaLocation")
    private String schemaLocation;

    @JsonProperty("@type")
    private String type;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getHref() { return href; }
    public void setHref(String href) { this.href = href; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public ProductOrderRef getProductOrder() { return productOrder; }
    public void setProductOrder(ProductOrderRef productOrder) { this.productOrder = productOrder; }
    public List<Characteristic> getCharacteristic() { return characteristic; }
    public void setCharacteristic(List<Characteristic> characteristic) { this.characteristic = characteristic; }
    public RelatedPlace getPlace() { return place; }
    public void setPlace(RelatedPlace place) { this.place = place; }
    public RiskAssessmentResult getRiskAssessmentResult() { return riskAssessmentResult; }
    public void setRiskAssessmentResult(RiskAssessmentResult riskAssessmentResult) { this.riskAssessmentResult = riskAssessmentResult; }
    public String getBaseType() { return baseType; }
    public void setBaseType(String baseType) { this.baseType = baseType; }
    public String getSchemaLocation() { return schemaLocation; }
    public void setSchemaLocation(String schemaLocation) { this.schemaLocation = schemaLocation; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}