package com.example.tmf696.model;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "Enumeration of risk types")
public enum RiskType {
    FraudRisk,
    BadPaymentRisk,
    CreditGamingRisk,
    IDConfidenceRisk,
    PaymentMethodRisk
}
