package com.example.tmf696.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Score for a specific risk type")
public class RiskScore {
    @ApiModelProperty(value = "Type of risk being scored", required = true)
    private RiskType riskName;

    @ApiModelProperty(value = "Numeric score for the risk", required = true)
    private Float score;

    @JsonProperty("@baseType")
    private String baseType;

    @JsonProperty("@schemaLocation")
    private String schemaLocation;

    @JsonProperty("@type")
    private String type;

    // Getters and Setters
    public RiskType getRiskName() { return riskName; }
    public void setRiskName(RiskType riskName) { this.riskName = riskName; }
    public Float getScore() { return score; }
    public void setScore(Float score) { this.score = score; }
    public String getBaseType() { return baseType; }
    public void setBaseType(String baseType) { this.baseType = baseType; }
    public String getSchemaLocation() { return schemaLocation; }
    public void setSchemaLocation(String schemaLocation) { this.schemaLocation = schemaLocation; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
