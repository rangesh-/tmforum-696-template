package com.example.tmf696.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Reference to a product order")
public class ProductOrderRef {
    @ApiModelProperty(value = "Unique identifier of the product order", required = true)
    private String id;

    @ApiModelProperty(value = "Reference of the product order")
    private String href;

    @ApiModelProperty(value = "Name of the product order")
    private String name;

    @JsonProperty("@referredType")
    private String referredType;

    @JsonProperty("@baseType")
    private String baseType;

    @JsonProperty("@schemaLocation")
    private String schemaLocation;

    @JsonProperty("@type")
    private String type;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getHref() { return href; }
    public void setHref(String href) { this.href = href; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getReferredType() { return referredType; }
    public void setReferredType(String referredType) { this.referredType = referredType; }
    public String getBaseType() { return baseType; }
    public void setBaseType(String baseType) { this.baseType = baseType; }
    public String getSchemaLocation() { return schemaLocation; }
    public void setSchemaLocation(String schemaLocation) { this.schemaLocation = schemaLocation; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
