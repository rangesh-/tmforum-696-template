package com.example.riskmanagement.controller;

import com.example.riskmanagement.model.ProductOrderRiskAssessment;
import com.example.riskmanagement.service.ProductOrderRiskAssessmentService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tmf-api/riskManagement/v4/productOrderRiskAssessment")
@Api(tags = {"Product Order Risk Assessment"})
public class ProductOrderRiskAssessmentController {

    @Autowired
    private ProductOrderRiskAssessmentService service;

    @GetMapping
    @ApiOperation(
        value = "List or find ProductOrderRiskAssessment objects",
        notes = "This operation list or find ProductOrderRiskAssessment entities",
        response = ProductOrderRiskAssessment.class,
        responseContainer = "List"
    )
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Successfully retrieved list"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 500, message = "Internal server error")
    })
    public List<ProductOrderRiskAssessment> listProductOrderRiskAssessments(
            @ApiParam(value = "Comma-separated properties to be provided in response")
            @RequestParam(required = false) String fields,
            
            @ApiParam(value = "Requested index for start of resources to be provided in response")
            @RequestParam(required = false) Integer offset,
            
            @ApiParam(value = "Requested number of resources to be provided in response")
            @RequestParam(required = false) Integer limit,
            
            @ApiParam(value = "Status of the risk assessment")
            @RequestParam(required = false) String status) {
        
        return service.findAll(status, limit, offset);
    }

    @GetMapping("/{id}")
    @ApiOperation(
        value = "Retrieves a ProductOrderRiskAssessment by ID",
        notes = "This operation retrieves a ProductOrderRiskAssessment entity.",
        response = ProductOrderRiskAssessment.class
    )
    @ApiResponses(value = {
        @ApiResponse(code = 200, message = "Successfully retrieved"),
        @ApiResponse(code = 404, message = "Not found"),
        @ApiResponse(code = 500, message = "Internal server error")
    })
    public ProductOrderRiskAssessment getProductOrderRiskAssessment(
            @ApiParam(value = "Identifier of the ProductOrderRiskAssessment", required = true)
            @PathVariable String id,
            
            @ApiParam(value = "Comma-separated properties to provide in response")
            @RequestParam(required = false) String fields) {
        
        return service.findById(id);
    }

    @PostMapping
    @ApiOperation(
        value = "Creates a ProductOrderRiskAssessment",
        notes = "This operation creates a ProductOrderRiskAssessment entity.",
        response = ProductOrderRiskAssessment.class
    )
    @ApiResponses(value = {
        @ApiResponse(code = 201, message = "Successfully created"),
        @ApiResponse(code = 400, message = "Bad request"),
        @ApiResponse(code = 500, message = "Internal server error")
    })
    public ResponseEntity<ProductOrderRiskAssessment> createProductOrderRiskAssessment(
            @ApiParam(value = "The ProductOrderRiskAssessment to be created", required = true)
            @RequestBody ProductOrderRiskAssessment productOrderRiskAssessment) {
        
        ProductOrderRiskAssessment created = service.create(productOrderRiskAssessment);
        return ResponseEntity.created(created.getHref())
                .body(created);
    }

    @DeleteMapping("/{id}")
    @ApiOperation(
        value = "Deletes a ProductOrderRiskAssessment",
        notes = "This operation deletes a ProductOrderRiskAssessment entity."
    )
    @ApiResponses(value = {
        @ApiResponse(code = 204, message = "Successfully deleted"),
        @ApiResponse(code = 404, message = "Not found"),
        @ApiResponse(code = 500, message = "Internal server error")
    })
    public ResponseEntity<Void> deleteProductOrderRiskAssessment(
            @ApiParam(value = "Identifier of the ProductOrderRiskAssessment", required = true)
            @PathVariable String id) {
        
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}