package com.example.tmf696.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Describes a given characteristic of an object or entity through a name/value pair")
public class Characteristic {
    @ApiModelProperty(value = "Unique identifier of the characteristic")
    private String id;

    @ApiModelProperty(value = "Name of the characteristic", required = true)
    private String name;

    @ApiModelProperty(value = "Value of the characteristic")
    private Object value;

    @ApiModelProperty(value = "Data type of the value of the characteristic")
    private String valueType;

    @JsonProperty("@baseType")
    private String baseType;

    @JsonProperty("@schemaLocation")
    private String schemaLocation;

    @JsonProperty("@type")
    private String type;

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Object getValue() { return value; }
    public void setValue(Object value) { this.value = value; }
    public String getValueType() { return valueType; }
    public void setValueType(String valueType) { this.valueType = valueType; }
    public String getBaseType() { return baseType; }
    public void setBaseType(String baseType) { this.baseType = baseType; }
    public String getSchemaLocation() { return schemaLocation; }
    public void setSchemaLocation(String schemaLocation) { this.schemaLocation = schemaLocation; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
